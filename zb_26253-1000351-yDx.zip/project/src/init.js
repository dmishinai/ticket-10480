bind ("postProcess", function($context) {
    if (!$context.session.path) {
        $context.session.path = []
        $context.session.path.push($context.currentState)
    } else {
        $context.session.path.push($context.currentState)
    };
    }, '/'
);
bind("selectNLUResult", function($context) {
    log($context.nluResults);

    if ($context.nluResults.intents.length > 0) {
        $context.nluResults.selected = $context.nluResults.intents[0];
        return;
    }

    if ($context.nluResults.patterns.length > 0) {
        $context.nluResults.selected = $context.nluResults.patterns[0];
    }
});

bind("postProcess", function($context) {
    $dialer.setNoInputTimeout(15000);
});