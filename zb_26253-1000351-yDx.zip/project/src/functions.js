function countRepeats(key, phrase1, phrase2, phrase3, targetState, LOG, limit) {
    var state = key;
    // $reactions.answer(targetState)
    var $session = $jsapi.context().session;
    $session.repeats = $session.repeats || {};
    $session.repeats[state] = $session.repeats[state] ? $session.repeats[state] + 1 : 1;
    log(key + " count: " + $session.repeats[state]);
    
    if ($session.repeats[state] < limit){
        if ($session.repeats[state] === 1){
            $reactions.answer(phrase1)
        } else if ($session.repeats[state] === 2 && phrase2 != ''){
            $reactions.answer(phrase2)
        } else if ($session.repeats[state] === 2 && targetState != '/' + key + '/0') {
            $reactions.transition({value: targetState, deffered: false})
        }
    }
    
    else {
        $reactions.answer(phrase3)
        hangUp(LOG);
    };
}
function hangUp(LOG) {
    log(LOG);
    $dialer.setCallResult(LOG);
    $analytics.setSessionResult(LOG);
    $dialer.hangUp(LOG);
    $jsapi.stopSession();
}
function fetchingReportTEST(CarPlateNumber, DateOfTheAccident){
    var API_KEY = '60139c5388d67f2b511b1872aaa6b14d'
    // var url = 'https://test-lairdassessors.swift-case.co.uk/api/v2/' + API_KEY + '/task/answers?includeDeleted=0&workflowIds[]=958&workflowIds[]=70&63=' + CarPlateNumber + '&13=' + DateOfTheAccident + '&orderBy=createdOn&workflowId=12&orderDir=DESC&maxResults=1'
    var url = 'https://test-lairdassessors-clone.swift-case.co.uk/api/v2/' + API_KEY + '/task/answers?includeDeleted=0&workflowIds[]=958&workflowIds[]=70&63=' + CarPlateNumber + '&13=' + DateOfTheAccident + '&orderBy=createdOn&workflowId=12&orderDir=DESC&maxResults=1'
    var response = $http.get(url)
    var taskIds = ''
    if (response.isOk) {
        if (response.data["task_ids"].length === 0) {
            taskIds = 'NO FILE'
        } else {
           taskIds = response.data["task_ids"][0]["id"] 
        };
        // $reactions.answer(response.data["task_ids"][0]["id"])
        log('TASK IDS: ' + taskIds)
    } else {
        taskIds = 'REQUEST FAILED'

    };
    return taskIds
}
function checkingTasksTEST(TaskId){
    if (TaskId === 'REQUEST FAILED') {
        reportStatus = 'REQUEST FAILED'
        repairStatus = 'REQUEST FAILED'
    } else if (TaskId === 'NO FILE') {
        reportStatus = 'NO FILE'
        repairStatus = 'NO FILE'
    } else {
        var API_KEY = '60139c5388d67f2b511b1872aaa6b14d'
        // var url = 'https://test-lairdassessors.swift-case.co.uk/api/v2/' + API_KEY + '/task/' + TaskId
        var url = 'https://test-lairdassessors-clone.swift-case.co.uk/api/v2/' + API_KEY + '/task/' + TaskId
        var response = $http.get(url)
        var repairStatus = ''
        var reportStatus = ''
        if (response.isOk) {
            repairStatus = response.data["data"][15]["value"]
            log("REPAIR STATUS: " + repairStatus)
            log("CLIENT INFO: " + toPrettyString(response.data["data"]))
            
            reportStatus = response.data["status"]["status"]
            log("REPORT STATUS: " + reportStatus)
        } else {
            repairStatus = 'REQUEST FAILED'
            reportStatus = 'REQUEST FAILED'
        };
    };
    return repairStatus, reportStatus
}

function loginToChatGPT(){
    var url = 'sec01-cp.eu-prod.int:9000/login'
    var options = {
                    dataType: "json",
                    headers: {
                            "Content-Type": "application/json"
                            },
                    body: {
                            "username": "justailaird",
                            "password": "9AWk19hRZWFH9fBBBVjm0rfc6Wx4MSEz"
                        }
                    };
    
    var response = $http.post(url, options);
    log("LOGIN TOKEN " + response.data["token"])
    if (response.isOk) {
        return response.data["token"]
    } else {
        return "Authorization failed"
    };
}

function Chat_Send_text(messageInfo, login_token){
    var url = "sec01-cp.eu-prod.int:9000/api/create";
           
    var options = {
                    dataType: "json",
                    headers: {
                            "Content-Type": "application/json",
                            "Authorization": login_token
                            },
                    body: messageInfo
                    };
                    
                                    	
    var response = $http.post(url, options);
    log("MESSAGE ID: " + response.data["taskID"])
    //$reactions.answer(response.data["id"]);
    if(response.isOk) {
        return response.data["taskID"]
    } else {
        return "NotFound"
    };
}

function Chat_Get_answer(id, login_token){
    var url = "sec01-cp.eu-prod.int:9000/api/get?task_id=" + id
           
    var options = {
                    headers: {
                            "Content-Type": "application/json",
                            "Authorization": login_token
                            }
                    };
                                    	
    var response = $http.get(url, options);
    //$reactions.answer(response.data["text"])
    if(response.isOk) {
        return response.data["Answer"]
    } else {
        return "Not Found"
    };
}

// function sendRequestToGPT(Messages) {
//     var GPT_TOKEN = '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'
//     var url = 'https://api.openai.com/v1/chat/completions'
//     var options = {
//                     headers: {
//                                 "Content-Type": "application/json",
//                                 "Authorization": "Bearer " + GPT_TOKEN
//                             },
//                     body: {
//                             "model": "gpt-3.5-turbo-1106",
//                             "messages": Messages
//                     }
//     }
//     log("CHAT GPT HISTORY: " + toPrettyString(Messages))
//     var response = $http.post(url, options)
//     if (response.isOk) {
//         log("CHAT GPT RESPONSE: " + response.data.choices[0].message.content)
//         return  response.data.choices[0].message.content
//     } else {
//         // log("CHAT GPT RESPONSE: " + response.data)
//         return "REQUEST FAILED"
//     };
// }

function sendTicketToTSTEST(email, telephoneNumber, TaskId, comment) {
    var API_KEY = '60139c5388d67f2b511b1872aaa6b14d'
    var options = {
                    dataType: "json",
                    headers: {
                            "Content-Type": "application/json"
                            },
                    body: {
                        "workflow_type_id": '1005',
                        "parent_oredrline_id": TaskId,
                        "data": [
                            {"name": "enquiry_email_address", "value": email},
                            {"name": "phone_number", "value": telephoneNumber},
                            {"name": "comment", "value": comment}
                            ]
                        }
                    };
    
    // var task = {
    //             "workflow_type_id": 1005,
    //             "parent_oredrline_id": TaskId,
    //             "data": [
    //                 {"name": "enquiry_email_address", "value": email},
    //                 {"name": "phone_number", "value": telephoneNumber},
    //                 {"name": "comment", "value": comment}
    //                 ]
    //             }
    var url = 'https://lairdassessors.swiftcase.co.uk/api/v2/' + API_KEY + '/task.json'
    var response = $http.post(url, options)
    
    return response
}