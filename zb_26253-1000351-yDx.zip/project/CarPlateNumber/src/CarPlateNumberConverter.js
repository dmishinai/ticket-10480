$global.$converters = $global.$converters || {};
var cnv = $global.$converters;

cnv.alphabetConverterValue = function(parseTree) {
    return parseTree.value;
};

cnv.CarPlateNumberConverter = function(pt) {
    var collectedValues = cnv.collectParseTreeValues(pt);
    var carPlateNumber = []
    log('CAR PLATE PATTERN ' + pt.pattern)
    log('COLLECTED VALUES: ' + collectedValues)
    if (pt.pattern === 'CarPlateNumberV2'){
        carPlateNumber.push(collectedValues[0])
        carPlateNumber.push(collectedValues[1].join(''))
        carPlateNumber.push(collectedValues[2])
        carPlateNumber.push(collectedValues[3])
        carPlateNumber.push(collectedValues[4])
    } else if (pt.pattern === 'CarPlateNumberV1') {
        carPlateNumber.push(collectedValues[0])
        carPlateNumber.push(collectedValues[1])
        carPlateNumber.push(collectedValues[2].join(''))
        carPlateNumber.push(collectedValues[3])
        carPlateNumber.push(collectedValues[4])
        carPlateNumber.push(collectedValues[5])
    } else {
        for (var i = 0; i < collectedValues.length; i ++) {
            carPlateNumber.push(collectedValues[i])
        };
    };
  
    carPlateNumber = carPlateNumber.join('')
    return carPlateNumber;
};

cnv.SameDigitsConverter = function(pt) {
    var times = parseInt(pt.value);
    var number = pt.NumberOneDigit ? pt.NumberOneDigit[0].value : 0;
    var output = "";

    for (var i = 0; i < times; ++i) {
        output += number;
    }
    return output
};

cnv.CarPlateNamesConverter = function($parseTree) {
    log("COLLECTED VALUES: " + toPrettyString($parseTree))
    var textPattern = $parseTree["words"]
    var indexDict = {}
    var carPlateNumber = ''
    var count = 0
    for (var i = 0; i < textPattern.length; i++) {
        for (var k = 0; k < $parseTree.Names.length; k++) {
            if (textPattern[i] === $parseTree.Names[k].text.toLowerCase()) {
                indexDict[i] = Names[$parseTree.Names[k].value].value.letter
            }; 
        };
        if ("NumberOneDigit" in $parseTree.Number[0] && !indexDict[i]) {
            indexDict[i] = $parseTree.Number[0].value[count]
            count += 1
        } else {
            for (var k = 0; k < $parseTree.Number.length; k++) {
                if (textPattern[i] === $parseTree.Number[k].text) {
                    indexDict[i] = $parseTree.Number[k].value
                };
            };
        };
    };
    log('INDEX: ' + toPrettyString(indexDict))
    for (var i = 0; i < Object.keys(indexDict).length; i ++) {
        carPlateNumber += indexDict[i]
    };
    return carPlateNumber
};

cnv.CarPlateLetterForName = function ($parseTree) {
    var collectedValues = cnv.collectParseTreeValues($parseTree)
    var carPlateNumber = ''
    for (var i = 0; i < collectedValues.length; i++) {
        if (!parseInt(collectedValues[i])) {
            carPlateNumber += collectedValues[i]
        } else if (collectedValues[i] in $parseTree.words) {
            carPlateNumber += collectedValues[i]
        };
    };
    
    return carPlateNumber
    
}